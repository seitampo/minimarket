import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>MiniMarket PVL</h1>
      <p>Добро пожаловать! Здесь будет ваш интернет-магазин.</p>
    </div>
  );
}

export default App;
